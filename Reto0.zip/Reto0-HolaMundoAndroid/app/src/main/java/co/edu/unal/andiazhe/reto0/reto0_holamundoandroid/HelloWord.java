package co.edu.unal.andiazhe.reto0.reto0_holamundoandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HelloWord extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello_word);
    }
}
