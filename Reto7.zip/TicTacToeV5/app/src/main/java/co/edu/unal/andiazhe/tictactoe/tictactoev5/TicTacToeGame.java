package co.edu.unal.andiazhe.tictactoe.tictactoev5;

import android.widget.Button;

import java.util.Random;


public class TicTacToeGame {

    public static final int BOARD_SIZE = 9;
    public static final int DIFFICULTY_EASY = 0;
    public static final int DIFFICULTY_HARD = 1;
    public static final int DIFFICULTY_EXPERT = 2;

    public static final String HUMAN_PLAYER = "X";
    public static final String COMPUTER_PLAYER = "O";

    private int difficulty = DIFFICULTY_EXPERT;

    private Random mRand = new Random();

    public int getComputerMove(Button[] mBoard) {
        int move = -1;
        switch (difficulty) {
            case DIFFICULTY_EASY:
                move = easyMove(mBoard);
                break;
            case DIFFICULTY_HARD:
                move = hardMove(mBoard);
                break;
            case DIFFICULTY_EXPERT:
                move = expertMove(mBoard);
                break;
        }

        mBoard[move].setText(COMPUTER_PLAYER);
        return move;
    }

    private int easyMove(Button[] mBoard) {
        int move;
        do {
            move = mRand.nextInt(BOARD_SIZE);
        } while (mBoard[move].getText().toString().equals(HUMAN_PLAYER)
                || mBoard[move].getText().toString().equals(COMPUTER_PLAYER));
        return move;
    }

    private int hardMove(Button[] mBoard) {
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (!mBoard[i].getText().toString().equals(HUMAN_PLAYER)
                    && !mBoard[i].getText().toString().equals(COMPUTER_PLAYER)) {
                String curr = mBoard[i].getText().toString();
                mBoard[i].setText(COMPUTER_PLAYER);
                if (checkForWinner(mBoard) == 3) {
                    return i;
                }
                mBoard[i].setText(curr);
            }
        }
        return easyMove(mBoard);
    }

    private int expertMove(Button[] mBoard) {
        int move;

        // First see if there's a move O can make to win
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (!mBoard[i].getText().toString().equals(HUMAN_PLAYER)
                    && !mBoard[i].getText().toString().equals(COMPUTER_PLAYER)) {
                String curr = mBoard[i].getText().toString();
                mBoard[i].setText(COMPUTER_PLAYER);
                if (checkForWinner(mBoard) == 3) {
                    return i;
                }
                mBoard[i].setText(curr);
            }
        }

        // See if there's a move O can make to block X from winning
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (!mBoard[i].getText().toString().equals(HUMAN_PLAYER)
                    && !mBoard[i].getText().toString().equals(COMPUTER_PLAYER)) {
                String curr = mBoard[i].getText().toString();   // Save the current number
                mBoard[i].setText(HUMAN_PLAYER);
                if (checkForWinner(mBoard) == 2) {
                    mBoard[i].setText(COMPUTER_PLAYER);
                    return i;
                }
                mBoard[i].setText(curr);
            }
        }

        // Generate random move
        move = easyMove(mBoard);
        return move;
    }

    public int checkForWinner(Button[] mBoard) {

        // Check horizontal wins
        for (int i = 0; i <= 6; i += 3) {
            if (mBoard[i].getText().toString().equals(HUMAN_PLAYER) &&
                    mBoard[i + 1].getText().toString().equals(HUMAN_PLAYER) &&
                    mBoard[i + 2].getText().toString().equals(HUMAN_PLAYER))
                return 2;
            if (mBoard[i].getText().toString().equals(COMPUTER_PLAYER) &&
                    mBoard[i + 1].getText().toString().equals(COMPUTER_PLAYER) &&
                    mBoard[i + 2].getText().toString().equals(COMPUTER_PLAYER))
                return 3;
        }

        // Check vertical wins
        for (int i = 0; i <= 2; i++) {
            if (mBoard[i].getText().toString().equals(HUMAN_PLAYER) &&
                    mBoard[i + 3].getText().toString().equals(HUMAN_PLAYER) &&
                    mBoard[i + 6].getText().toString().equals(HUMAN_PLAYER))
                return 2;
            if (mBoard[i].getText().toString().equals(COMPUTER_PLAYER) &&
                    mBoard[i + 3].getText().toString().equals(COMPUTER_PLAYER) &&
                    mBoard[i + 6].getText().toString().equals(COMPUTER_PLAYER))
                return 3;
        }

        // Check for diagonal wins
        if ((mBoard[0].getText().toString().equals(HUMAN_PLAYER) &&
                mBoard[4].getText().toString().equals(HUMAN_PLAYER) &&
                mBoard[8].getText().toString().equals(HUMAN_PLAYER)) ||
                (mBoard[2].getText().toString().equals(HUMAN_PLAYER) &&
                        mBoard[4].getText().toString().equals(HUMAN_PLAYER) &&
                        mBoard[6].getText().toString().equals(HUMAN_PLAYER)))
            return 2;
        if ((mBoard[0].getText().toString().equals(COMPUTER_PLAYER) &&
                mBoard[4].getText().toString().equals(COMPUTER_PLAYER) &&
                mBoard[8].getText().toString().equals(COMPUTER_PLAYER)) ||
                (mBoard[2].getText().toString().equals(COMPUTER_PLAYER) &&
                        mBoard[4].getText().toString().equals(COMPUTER_PLAYER) &&
                        mBoard[6].getText().toString().equals(COMPUTER_PLAYER)))
            return 3;

        // Check for tie
        for (int i = 0; i < BOARD_SIZE; i++) {
            // If we find a number, then no one has won yet
            if (!mBoard[i].getText().toString().equals(HUMAN_PLAYER)
                    && !mBoard[i].getText().toString().equals(COMPUTER_PLAYER))
                return 0;
        }
        return 1;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }
}
