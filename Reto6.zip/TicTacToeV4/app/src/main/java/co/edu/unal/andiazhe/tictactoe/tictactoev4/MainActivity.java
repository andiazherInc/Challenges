package co.edu.unal.andiazhe.tictactoe.tictactoev4;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button btnBoard[];
    private TextView txtInfo;
    private TextView txtWins;
    private TextView txtTies;
    private TextView txtLoses;

    private boolean humanFirst;
    private int wins;
    private int ties;
    private int loses;
    private SharedPreferences sharedPref;

    private TicTacToeGame mGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBoard = new Button[TicTacToeGame.BOARD_SIZE];
        btnBoard[0] = (Button) findViewById(R.id.one);
        btnBoard[1] = (Button) findViewById(R.id.two);
        btnBoard[2] = (Button) findViewById(R.id.three);
        btnBoard[3] = (Button) findViewById(R.id.four);
        btnBoard[4] = (Button) findViewById(R.id.five);
        btnBoard[5] = (Button) findViewById(R.id.six);
        btnBoard[6] = (Button) findViewById(R.id.seven);
        btnBoard[7] = (Button) findViewById(R.id.eight);
        btnBoard[8] = (Button) findViewById(R.id.nine);

        txtInfo = (TextView) findViewById(R.id.txtInfo);
        txtWins = (TextView) findViewById(R.id.txtWins);
        txtTies = (TextView) findViewById(R.id.txtTies);
        txtLoses = (TextView) findViewById(R.id.txtLoses);


        sharedPref = getSharedPreferences("pf", Context.MODE_PRIVATE);
        humanFirst = sharedPref.getBoolean("goFirst", true);
        wins = sharedPref.getInt("wins", 0);
        ties = sharedPref.getInt("ties", 0);
        loses = sharedPref.getInt("loses", 0);


        txtWins.setText(getString(R.string.wins) + ": " + wins);
        txtTies.setText(getString(R.string.ties) + ": " + ties);
        txtLoses.setText(getString(R.string.loses) + ": " + loses);

        mGame = new TicTacToeGame();

        startNewGame();
    }

    private void startNewGame() {
        clearBoard();
        for (int i = 0; i < btnBoard.length; i++) {
            final int finalI = i;
            btnBoard[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (btnBoard[finalI].isEnabled()) {
                        humanMove(finalI);
                    }
                }
            });
        }
        if (humanFirst) {
            txtInfo.setText(R.string.go_first);
        } else {
            androidMove();
        }
        sharedPref.edit().putBoolean("goFirst", humanFirst = !humanFirst).apply();
    }

    private void humanMove(int position) {
        setMove(TicTacToeGame.HUMAN_PLAYER, position);
        if (!checkWinner()) {
            androidMove();
        }
    }

    private void androidMove() {
        txtInfo.setText(R.string.android_turn);
        int move = mGame.getComputerMove(btnBoard);
        setMove(TicTacToeGame.COMPUTER_PLAYER, move);
        checkWinner();
    }

    private boolean checkWinner() {
        int winner = mGame.checkForWinner(btnBoard);
        switch (winner) {
            case 0:
                txtInfo.setText(R.string.you_turn);
                return false;
            case 1:
                sharedPref.edit().putInt("ties", ++ties).apply();
                txtTies.setText(getString(R.string.ties) + ": " + ties);
                txtInfo.setText(R.string.tie);
                return true;
            case 2:
                sharedPref.edit().putInt("wins", ++wins).apply();
                txtWins.setText(getString(R.string.wins) + ": " + wins);
                txtInfo.setText(R.string.you_win);
                return true;
            case 3:
                sharedPref.edit().putInt("loses", ++loses).apply();
                txtLoses.setText(getString(R.string.loses) + ": " + loses);
                txtInfo.setText(R.string.android_win);
                return true;
            default:
                return false;
        }
    }

    private void clearBoard() {
        for (Button mBoardButton : btnBoard) {
            mBoardButton.setText("");
            mBoardButton.setEnabled(true);
        }
        txtInfo.setText(R.string.go);
    }

    private void setMove(String player, int location) {
        btnBoard[location].setEnabled(false);
        btnBoard[location].setText(player);
        if (player.equals(TicTacToeGame.HUMAN_PLAYER)) {
            btnBoard[location].setTextColor(Color.rgb(0, 200, 0));
        } else {
            btnBoard[location].setTextColor(Color.rgb(200, 0, 0));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_new_game:
                startNewGame();
                break;
            case R.id.action_difficulty:
                ArrayList<String> list = new ArrayList<>();
                list.add(getString(R.string.easy));
                list.add(getString(R.string.hard));
                list.add(getString(R.string.expert));
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
                DialogHandler.showListDialog(this, R.string.select_difficulty, adapter, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                mGame.setDifficulty(TicTacToeGame.DIFFICULTY_EASY);
                                break;
                            case 1:
                                mGame.setDifficulty(TicTacToeGame.DIFFICULTY_HARD);
                                break;
                            case 2:
                                mGame.setDifficulty(TicTacToeGame.DIFFICULTY_EXPERT);
                                break;
                        }
                    }
                });
                break;
            case R.id.action_reset:
                resetStatistics();
                break;
            case R.id.action_exit:
                DialogHandler.showConfirmationDialog(this, R.string.are_you_sure, R.string.exit_message,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                finish();
                            }
                        }, null);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void resetStatistics() {
        sharedPref.edit().clear().apply();
        humanFirst = true;
        wins = 0;
        ties = 0;
        loses = 0;
        txtWins.setText(getString(R.string.wins) + ": " + wins);
        txtTies.setText(getString(R.string.ties) + ": " + ties);
        txtLoses.setText(getString(R.string.loses) + ": " + loses);
        startNewGame();
    }
}
